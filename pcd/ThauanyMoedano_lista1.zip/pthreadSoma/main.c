/* Programas para calcular a soma total dos valores de um vetor de tamanho N
utilizando threads.

Thauany Moedano
RA 92486 */

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
//Constantes
#define N 10000000
#define MAX_THREADS 8

//Estrutura da thread
typedef struct thread_information{
    int thread_id;
    int start;
    int end;
} TInformation;

//Variaveis globais
float *array;  //array global que determina o valor a ter os valores somados
float *retorno; //array global que guarda a soma local de cada thread
TInformation thread_interval[MAX_THREADS]; //Struct da thread



//Fun��o principal da thread
void *sum(void *t_inf) {
  int i, value;
  int seed;
  TInformation *inf = (TInformation*) t_inf;
  float localSum = 0; //variavel que guarda a soma local

  //Populando o vetor
  for(i = inf->start; i <= inf->end; i++) {
      seed = time(NULL);
      value = rand_r(&seed)%10;
      array[i] = value;

   }

  for(i = inf->start; i <= inf->end; i++)
     localSum += array[i]; //soma local do trecho do vetor

   retorno[inf->thread_id] = localSum; //Armazenando a soma local
}

int main(void){
  pthread_t t[MAX_THREADS];
  float globalSum = 0.0;
  int i, ratio;
  struct timeval inicio, final2;
  int tmili;

  array = (float*) malloc(N*sizeof(float));
  retorno = (float*) malloc(MAX_THREADS*sizeof(float));
  ratio = N/MAX_THREADS;  //A razao divide o trecho que cada thread fara a soma




    //Populando a thread
   for(i = 0 ; i < MAX_THREADS; i++){
        thread_interval[i].thread_id = i;
        thread_interval[i].start = ratio*i;
        thread_interval[i].end = ((i!=(MAX_THREADS-1)) ? ((ratio*(i+1))-1) : N-1);
    }


  gettimeofday(&inicio, NULL);
  //criando as thread
  for(i = 0; i < MAX_THREADS; i++) {
    pthread_create(&t[i], NULL, &sum, (void *)&thread_interval[i]);
  }

  //Juntando as threads e preenchendo o vetor
  for(i = 0; i < MAX_THREADS; i++) {
    pthread_join(t[i],NULL);
    globalSum += retorno[i];
  }

  gettimeofday(&final2, NULL);
  tmili = (int) (1000 * (final2.tv_sec - inicio.tv_sec) + (final2.tv_usec - inicio.tv_usec) / 1000);
  printf("media global = %f\n", globalSum/N);
  printf("tempo decorrido: %d milisegundos\n", tmili);



  return 0;
}
