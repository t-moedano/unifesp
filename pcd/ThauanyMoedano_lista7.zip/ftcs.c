#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpi.h>
#include <time.h>
#include <sys/time.h>

#define tam 1.0
#define dx 0.00001
#define dt 0.000001
#define T  0.01
#define kappa 0.000045 

int main(int argc, char *argv[]){
    double *tmp, *u, *u_prev, *localMax;
    double x, t, max, tmiliThreads;
    int n;
    int *localPos;
    int i, pos, begin, next, previous, length, localSize, nProcess, thisProcessId, howMany, remain, first, last, processId, nlocal;
    struct timeval inicioThreads, fimThreads;
    MPI_Status status;

    MPI_Init(&argc,&argv);

    MPI_Comm_size(MPI_COMM_WORLD, &nProcess);
    MPI_Comm_rank(MPI_COMM_WORLD, &processId);

    if(thisProcessId==0)
        gettimeofday(&inicioThreads,NULL);

    n = tam/dx;
  //n = 17;
  
        howMany = (n)/nProcess;
	first = processId*howMany + 1;
	
	if(processId == (nProcess-1))
		last = n;
	else
		last = (processId+1)*howMany;
	

    if(processId == 0 || processId == nProcess-1)    
        nlocal = last - first + 1 + 1;

    else
        nlocal = last - first + 2 + 1;
    
    
    printf("Tamanho de n: %d, quantidade de processos: %d\n", n, nProcess);
    printf(" Processo: %d nLocal: %d first: %d last %d\n", processId, nlocal, first, last);


    u = (double *) malloc((nlocal)*sizeof(double));
    u_prev = (double *) malloc((nlocal)*sizeof(double));
    localMax = (double*) malloc(nProcess*sizeof(double));
    localPos = (int*) malloc(nProcess*sizeof(int));
     
    x = (double)(first*dx);
    for(i = 0; i < nlocal; ++i){
        if(x<=0.5)
            u_prev[i] = 200*x;
        else
            u_prev[i] = 200*(1.0-x);
        x += dx;
    }
   
  	
    next = ((processId==nProcess-1) ? MPI_PROC_NULL : processId+1);
    previous = ((processId==0) ? MPI_PROC_NULL : processId-1);
    
    printf("Processo atual: %d - next: %d, previous: %d \n\n", processId, next, previous);

   printf("nLocal: %d\n\n", nlocal);	
   
    t = 0.0;
    u[0] = u[n] = 0.0;
    while(t<T)
    {
        MPI_Sendrecv(&u_prev[nlocal-2], 1, MPI_DOUBLE, next, 10,
             &u_prev[0], 1, MPI_DOUBLE, previous, 10,
             MPI_COMM_WORLD, &status);
        MPI_Sendrecv(&u_prev[1], 1, MPI_DOUBLE, previous, 10,
             &u_prev[nlocal-1], 1, MPI_DOUBLE, next, 10,
             MPI_COMM_WORLD, &status);
	     

	x = (double)(first*dx);
        for(i = 1; i < nlocal; ++i){
            u[i] = u_prev[i] + kappa*dt/(dx*dx)*(u_prev[i-1]-2*u_prev[i]+u_prev[i+1]);
            x += dx;
        }
        
        tmp = u_prev; 
        u_prev = u; 
        u = tmp;
        t += dt;
    }
   
   
    localPos[processId] = first-1;
    

    localMax[processId] = u[0];
    
    for(i = 0; i < nlocal; ++i)
        if(u[i] > localMax[processId])
        {
            localMax[processId] = u[i];
            localPos[processId] = first+i-1;
        }
           
 
    
    if(processId!=0){
        MPI_Send(&localMax[processId], 1, MPI_DOUBLE, 0, 12, MPI_COMM_WORLD);
        MPI_Send(&localPos[processId], 1, MPI_INTEGER, 0, 13, MPI_COMM_WORLD);
    }
    
    else{
        for(i=1; i< nProcess; ++i){
            MPI_Recv(&localMax[i], 1, MPI_DOUBLE, i, 12, MPI_COMM_WORLD, &status);
            MPI_Recv(&localPos[i], 1, MPI_INTEGER, i, 13, MPI_COMM_WORLD, &status);
        }
        
   
   
        pos = 0;
        for(i=1; i< nProcess; ++i){
            if(localMax[i] > localMax[pos])
                pos = i;
        max = localMax[pos];
        }
        
    
        gettimeofday(&fimThreads,NULL);
        tmiliThreads = (double)(1000.0*(fimThreads.tv_sec-inicioThreads.tv_sec)+(fimThreads.tv_usec-inicioThreads.tv_usec)/1000.0);
        printf("Maior valor u[%d] = %g\n", localPos[pos], max);
        printf("%d processos: tempo - %.3lf milliseconds\n", nProcess, tmiliThreads);
    }
   MPI_Finalize();
        //exit(0);
   return 0;
}
