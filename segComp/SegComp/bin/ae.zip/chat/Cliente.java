package chat;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import cipherModes.CBC;
import cipherModes.CTR;
import cipherModes.CipherMode;
import cipherModes.ECB;
import cipherModes.RC4;

public class Cliente {
    
    CipherMode cipherMode;
    public static void main(String[] args) 
                throws UnknownHostException, IOException 
    {
        // dispara cliente
        new Cliente().executa();
    }


    public void executa() throws UnknownHostException, IOException {
        
        GUI gui = new GUI();
        gui.createClientInterface();
        Socket cliente = new Socket(gui.getIp(), Integer.valueOf(gui.getClientPort()));
        setCipherMode(gui);
        
        gui.createChatScreen(cliente);
        // thread para receber mensagens do servidor
        Recebedor r = new Recebedor(cliente.getInputStream(), gui.getTextArea(), cipherMode);
        new Thread(r).start();

    }
    
    public void setCipherMode(GUI gui)
    {
        if(gui.getCipherMode().equals("ECB"))
        {
            cipherMode = new ECB();
        }
        else if(gui.getCipherMode().equals("CBC"))
        {
            cipherMode = new CBC();
        }
        else if(gui.getCipherMode().equals("CTR"))
        {
            cipherMode = new CTR();
        }
        else if(gui.getCipherMode().equals("RC4"))
        {
            cipherMode = new RC4("padrao".getBytes());
        }
            
    }
}
