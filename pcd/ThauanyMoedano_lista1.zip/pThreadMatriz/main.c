#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
//Constantes
#define N 1000
#define MAX_THREADS 8

//Estrutura da thread
typedef struct thread_information{
    int thread_id;
    int start;
    int end;
} TInformation;

//Variaveis globais
double **m1, **m2, **retorno;  // matrizes para soma
TInformation thread_interval[MAX_THREADS]; //Struct da thread



//Fun��o principal da thread
void *sum(void *t_inf) {
  int i, j;
  TInformation *inf = (TInformation*) t_inf;


    //Fazendo a soma
  for(i = inf->start; i <= inf->end; i++) {
    for(j = 0; j < N; j++)
       retorno[i][j] = m1[i][j] + m2[i][j];
   }

}

int main(void){


  int i, ratio, value;
  struct timeval inicio, final2;
  int tmili;
  int m, n;
  unsigned int seed = time(NULL);
  pthread_t t[MAX_THREADS];

  m1 = malloc (N * sizeof (double *));
   for (i = 0; i < N; i++)
      m1[i] = malloc (N * sizeof (double));

  m2 = malloc (N * sizeof (double *));
   for (i = 0; i < N; i++)
      m2[i] = malloc (N * sizeof (double));

  retorno = malloc (N * sizeof (double *));
   for (i = 0; i < N; i++)
      retorno[i] = malloc (N * sizeof (double));
    //Populando a matriz
   for(m = 0; m < N; m++)  {
        for(n = 0; n < N; n++) {
            value = rand_r(&seed)%10;
            m1[m][n] = value;

            value = rand_r(&seed)%10;
            m2[m][n] = value;
            //printf(" valor %f ", m1[m][n]);
        }
      //  printf("\n");
   }

 /* for(m = 0; m < N; m++) {
    for(n = 0; n < N; n++)
        printf("%.2f ", m1[m][n]);
    printf("\n");
  }
  printf("\n");
  for(m = 0; m < N; m++) {
    for(n = 0; n < N; n++)
        printf("%.2f ", m2[m][n]);
    printf("\n");
  }

  printf("\n");*/
  ratio = N/MAX_THREADS;  //A razao divide o trecho que cada thread fara a soma




    //Populando a thread
   for(i = 0 ; i < MAX_THREADS; i++){
        thread_interval[i].thread_id = i;
        thread_interval[i].start = ratio*i;
        thread_interval[i].end = ((i!=(MAX_THREADS-1)) ? ((ratio*(i+1))-1) : N-1);
    }


  gettimeofday(&inicio, NULL);
  //criando as thread
  for(i = 0; i < MAX_THREADS; i++) {
    pthread_create(&t[i], NULL, &sum, (void *)&thread_interval[i]);
  }

  //Juntando as threads
  for(i = 0; i < MAX_THREADS; i++) {
    pthread_join(t[i],NULL);

  }

  gettimeofday(&final2, NULL);
  tmili = (int) (1000 * (final2.tv_sec - inicio.tv_sec) + (final2.tv_usec - inicio.tv_usec) / 1000);



  printf("tempo decorrido: %d milisegundos\n", tmili);




  return 0;
}
