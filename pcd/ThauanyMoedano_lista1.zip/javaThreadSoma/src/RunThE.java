
class RunThE implements Runnable {
    final static int N = 10;
    public static float retorno[] = new float[N];
    private int inic, fim;
    // resultado da operação
    public double valor;
    // construtor
   
   
    public RunThE(int inic, int fim) {
        super();       
        this.inic = inic;
        this.fim = fim;
    }
   
   
    public void run() {
        float soma=0;
        for(int k=inic; k<fim; k++){
            retorno[k] = (float) (Math.random()*10);
            System.out.println(retorno[k]);
            soma += retorno[k];
           
        }
        valor = soma;
    }
}