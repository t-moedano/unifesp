#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

#define	N 10000000
#define MAX_THREADS 4

double globalSumy = 0.0, globalSumx = 0.0, globalSumxy = 0.0, globalSumxx = 0.0, m = 0.0, b = 0.0;
double *arrayX, *arrayY;

int main()
{
	int i;
	unsigned int seed = (unsigned int)time(NULL), tID;
	double rand, tmiliThreads, inicioThreads, fimThreads;	
	double localSUMx = 0.0, localSUMy = 0.0, localSUMxy = 0.0, localSUMxx = 0.0;

	arrayX = (double*) malloc(N*sizeof(double));
	arrayY = (double*) malloc(N*sizeof(double));
	
	for(i = 0; i < N; i++) 
	{
		arrayX[i] = ((double)i*10.0)/(double)N;
		rand = (double)rand_r(&seed)/(double)N;
		arrayY[i] = rand;  	
	}
	
	inicioThreads = omp_get_wtime();
    	omp_set_dynamic(0);
    	omp_set_num_threads(MAX_THREADS);

	 #pragma omp parallel private(i)
       	 {

	 #pragma omp for
         for(i = 0; i < N; i++)
	 {
            localSUMx += arrayX[i];
            localSUMy += arrayY[i];
            localSUMxy += arrayX[i]*arrayY[i];
            localSUMxx += arrayX[i]*arrayX[i];
         }

	 tID = omp_get_thread_num();

	 #pragma omp critical
        {
        	globalSumx += localSUMx;
        	globalSumy += localSUMy;
        	globalSumxy += localSUMxy;
        	globalSumxx += localSUMxx;
        }

	 #pragma omp barrier
        if(tID == 0){
            m = ((globalSumx*globalSumy)-(N*globalSumxy))/((globalSumx*globalSumx)-(N*globalSumxx));
            b = (globalSumy-(m*globalSumx))/N;                
        }
    }
   fimThreads = omp_get_wtime();
   tmiliThreads = (double) (fimThreads-inicioThreads)*1000.0;
    
    printf("y = %lfx + %lf\n", m, b);
    printf("Tempo decorrido com %d Threads: %.3lf milissegundos\n", MAX_THREADS, tmiliThreads);
    
    free(arrayX);
    free(arrayY);

    return 0;	
	
}	
