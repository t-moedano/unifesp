#include "mpi.h"
#include <math.h>
#include <stdio.h>
#include <time.h>
#include <sys/time.h>

#define N 100000000
#define u 2.0
int main(int argc, char *argv[])
{
    int myid, numprocs, i, rc;

    double localSum = 0.0, step = ((u-1) / (double) N), x, globalSum = 0.0,  tmiliThreads;
    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
    MPI_Comm_rank(MPI_COMM_WORLD,&myid);
   struct timeval inicioThreads, fimThreads;
       if(myid==0)
        gettimeofday(&inicioThreads,NULL);

    for (i = myid + 1; i <= N; i += numprocs)
    {
        x = 1 + ((double)i * step);
        localSum += 0.5*(1/x+1/(x+step));
    }
    localSum *= step;
    MPI_Reduce(&localSum, &globalSum, 1, MPI_DOUBLE, MPI_SUM, 0,
               MPI_COMM_WORLD);
    if (myid == 0)
        printf("Soma: %.5f\n", globalSum);
   gettimeofday(&fimThreads,NULL);
        tmiliThreads = (double)(1000.0*(fimThreads.tv_sec-inicioThreads.tv_sec)+(fimThreads.tv_usec-inicioThreads.tv_usec)/1000.0);
    if(myid==0)   
     printf("%d processos: tempo - %.3lf milliseconds\n", numprocs, tmiliThreads);
    MPI_Finalize();
    return 0;
}