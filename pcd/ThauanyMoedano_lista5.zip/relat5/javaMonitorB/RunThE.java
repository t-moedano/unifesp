
import java.util.*;
import java.util.concurrent.locks.*;

public class RunThE implements Runnable{
    static int numThreads, tCounter, counterLimit;
    static int counter;
    int id;
    public static final Object locker = new Object();

	public RunThE(int id, int numThreads, int tCounter, int counterLimit){
        
            RunThE.numThreads = numThreads;
            RunThE.tCounter = tCounter;
            RunThE.counterLimit = counterLimit;
            RunThE.counter = 0;
      
	    this.id = id;
	}
    public int getCounter(){
		return RunThE.counter;
	}
    private void count(){
        synchronized(locker){
            if(id==0){
                // watch_counter()
                try {
                    if(RunThE.counter<RunThE.counterLimit){
                    	System.out.println("watch_counter(): Thread " + id + " going into wait...");
                    	locker.wait();
                        System.out.println("watch_counter(): Thread " + id + " condition signal received");
                        RunThE.counter += 125;
                        System.out.println("watch_counter(): Thread " + id + " now counter = " + RunThE.counter);
        
                    }
                } catch (InterruptedException e){
                    System.err.println(e.toString());
                }            
            }
            else{
                // inc_counter()
                for(int i=0; i<RunThE.tCounter; i++){
                    RunThE.counter++;
                    if(RunThE.counter==RunThE.counterLimit){
                    	System.out.println("inc_counter(): Thread " + id + "counter = " + RunThE.counter + " threshold reached");
                                           
                        locker.notifyAll();                  
                        
                        System.out.println("inc_counter(): Thread " + id + " counter = " + RunThE.counter + " just sent signal");
                    }
                    System.out.println("inc_counter(): Thread " + id  + " counter = " + RunThE.counter + ", unlocking locker");
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e){
                        System.err.println(e.toString());
                    }
                }
            }
        }
    }
	public void run(){
        	if(this.id==0)
        		System.out.println("Starting watch_counter(): Thread " + id);                     
        	else
        		System.out.println("Starting inc_counter(): Thread " + id);
        	this.count();
	}
}

