// classe de teste das threads
public class monitorJava {
    final static int N = 10000000;
    public static void main (String args[]) {
       
        
        double m, b;
        int MaxThreads = 4, i;
        int ratio = (N/MaxThreads);
        Thread[] th;
        initthread[] rh;
        rh = new initthread[MaxThreads];
        th = new Thread[MaxThreads];
   
       
        initthread.arrayX[0] = 0.0;
     
       
        long startTime = System.currentTimeMillis();
       
        for(i=0; i<MaxThreads; i++) {
            int end =  ((i!=(MaxThreads-1)) ? ((ratio*(i+1))-1) : N-1);
            rh[i] = new initthread(ratio*i, end);
            th[i] = new Thread(rh[i]);
            th[i].start();
        }

        try {
            for(i=0; i<MaxThreads; i++)
                th[i].join();           
        } catch (InterruptedException e)
        { System.out.println("Excecao"); }
       
        long calcTime = System.currentTimeMillis() - startTime;
      
        m = (initthread.SUMxglobal*initthread.SUMyglobal - N*initthread.SUMxyglobal)
                / (initthread.SUMxglobal*initthread.SUMxglobal - N*initthread.SUMxxglobal);
        b =  (initthread.SUMyglobal - m*initthread.SUMxglobal) / N;
        System.out.println("Função: y = " + m + "x + " + b);
    
        System.out.println("Em " + calcTime + "ms.\n");
       
    }
   
}
