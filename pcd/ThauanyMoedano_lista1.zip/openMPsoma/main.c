#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <assert.h>
#include <time.h>

#define N 10
#define MAX_THREADS 2

float *array;  //array global que determina o valor a ter os valores somados


int main()
{   int i, seed, value;
double start, end, run;
    seed = time(NULL);
    float retorno = 0;
    array = (float*) malloc(N*sizeof(float));
    start = omp_get_wtime();
    #pragma omp parallel private(i) private(seed) private(value) reduction(+:retorno)
    {
     #pragma omp for
     for(i = 0; i < N; i++) {

        value = rand_r(&seed)%100;
        array[i] = value;
        printf("Valor [%d]: %f\n", i, array[i]);
        retorno += array[i];

     }
    }

    printf("Valor %f", retorno/N);
     end = omp_get_wtime();
    printf(" took %f seconds.\n", end-start);
    return 0;
}
