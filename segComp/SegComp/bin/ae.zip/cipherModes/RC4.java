package cipherModes;


import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class RC4 implements CipherMode {
    private final int[] S = new int[256];
    private final byte[] T = new byte[256];
    private final int keylen;
    byte[] key;

    public void reset() {
        Arrays.fill(S, 0);
    }

    public RC4(byte key[]) {
        keylen = key.length;
        this.key = key;
        initS();
    }
    public String makeCipher(String texto){return "";}
    public String makePlainText(String texto){return "";}

    public byte[] makeCipher(byte[] texto) {
        final byte[] texto_cifrado = new byte[texto.length];
        int i = 0, j = 0, k, t;
        int aux;
        for (int cont = 0; cont < texto.length; cont++) {
            i = (i + 1) % 256;
            j = (j + S[i]) % 256;
            aux = S[j];
            S[j] = S[i];
            S[i] = aux;
            t = (S[i] + S[j]) % 256;
            k = S[t];
            texto_cifrado[cont] = (byte) (k ^ texto[cont]);
        }
        return texto_cifrado;
    }

    public byte[] makePlainText(byte[] texto_cifrado) {
        reset();
        initS();
        return makeCipher(texto_cifrado);
    }

    public void initS() {
        for (int i=0;i<256;i++) {
            S[i] = i;
            T[i] = key[i % keylen];
        }

        int j = 0;
        int aux;
        for (int i = 0; i < 256; i++) {
            j = (j + S[i] + T[i]) % 256;
            aux = S[j];
            S[j] = S[i];
            S[i] = aux;
        }
    }
}

