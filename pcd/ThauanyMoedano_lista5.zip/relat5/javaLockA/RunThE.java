
import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;

public class RunThE implements Runnable{
    static final Lock locker = new ReentrantLock();
    static final Condition conditionVariable = locker.newCondition();
     static int numThreads, tCounter, counterLimit;
     static int counter;
     int id;

	public RunThE(int id, int numThreads, int tCounter, int counterLimit){
        	
            	RunThE.numThreads = numThreads;
            	RunThE.tCounter = tCounter;
            	RunThE.counterLimit = counterLimit;
            	RunThE.counter = 0;
		this.id = id;
	}
    public int getCounter(){
	return RunThE.counter;
    }
	public void run(){
        if(this.id==1){
            // watch_counter()            
            System.out.println("Starting watch_counter(): Thread " + id);            
            RunThE.locker.lock();
            try {
                if(RunThE.counter<RunThE.counterLimit){
                    System.out.println("watch_counter(): Thread " + id + " going into wait...");
                    RunThE.conditionVariable.await();
                    System.out.println("watch_counter(): Thread " + id + " condition signal received");
                    RunThE.counter += 125;
                    System.out.println("watch_counter(): Thread " + id + " now counter = " + RunThE.counter);
                }
                RunThE.locker.unlock();
            } catch (InterruptedException e){
                    System.err.println(e.toString());
            }            
        }
        else{
            // inc_counter()
            System.out.println("Starting inc_counter(): Thread " + id);
            for(int i=0; i<tCounter; i++){
                locker.lock();
                RunThE.counter++;
                if(RunThE.counter==RunThE.counterLimit){
                  System.out.println("inc_counter(): Thread " + id + "counter = " + RunThE.counter + " threshold reached");
                  RunThE.conditionVariable.signal();
                  System.out.println("inc_counter(): Thread " + id + " counter = " + RunThE.counter + " just sent signal");
                }
                System.out.println("inc_counter(): Thread " + id  + " counter = " + RunThE.counter + ", unlocking locker");
                locker.unlock();
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e){
                    System.err.println(e.toString());
                }
            }
        }
	}
}

