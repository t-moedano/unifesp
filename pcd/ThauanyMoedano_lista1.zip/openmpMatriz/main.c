#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>
#include <assert.h>

#define N 1000
#define MAX_THREADS 2

double **m1, **m2;  //Matrizes globais acessadas pelas threads


int main()
{   int i, seed, value, j, m, n;
    seed = time(NULL);
    double start, end, run;

    double **retorno; //matriz de retorno

    //Populando a matriz
     m1 = malloc (N * sizeof (double *));
   for (i = 0; i < N; i++)
      m1[i] = malloc (N * sizeof (double));

  m2 = malloc (N * sizeof (double *));
   for (i = 0; i < N; i++)
      m2[i] = malloc (N * sizeof (double));

  retorno = malloc (N * sizeof (double *));
   for (i = 0; i < N; i++)
      retorno[i] = malloc (N * sizeof (double));

      for(m = 0; m < N; m++)  {
        for(n = 0; n < N; n++) {
            value = rand_r(&seed)%10;
            m1[m][n] = value;
            m2[m][n] = value;

        }

      }

  start = omp_get_wtime();
    #pragma omp parallel private(i) private(seed) private(value)
    {
     #pragma omp for
     for(i = 0; i < N; i++) {
        for(j = 0; j < N; j++) {
            retorno[i][j] = m1[i][j] + m2[i][j];
        }

     }
    }
      end = omp_get_wtime();
    printf("tempo decorrido: %.2f milissegundos \n", (end-start)*1000);
    return 0;
}
