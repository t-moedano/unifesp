
class RunThE implements Runnable {
   // final static int N = 10;
    public static float retorno[] = new float[CalcThE.N];
    private int inic, fim;
    // resultado da operação
    //public double valor;
    // construtor
   
   
    public RunThE(int inic, int fim) {
        super();       
        this.inic = inic;
        this.fim = fim;
    }
   
   
    public void run() {
      //  float soma = 0;
        int i, j;
        for(i = inic; i <= fim; i++){
        	for(j = 0; j < CalcThE.N; j++) {
        		CalcThE.retorno[i][j] = CalcThE.m1[i][j] + CalcThE.m2[i][j];
        		
        	}
        }	
      
    }
}