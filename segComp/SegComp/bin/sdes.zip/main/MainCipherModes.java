package main;

import cipherModes.ECB;

public class MainCipherModes
{

    public static void main(String[] args)
    {
        ECB ecb = new ECB();
        String string = "nao ha quem ganhar ou perder.. vai todo mundo perder";
        String cipherString = ecb.makeCipher(string);
        System.out.println(cipherString);
        String decrypt = ecb.makePlainText(cipherString);
        System.out.println(decrypt);
    }
}
