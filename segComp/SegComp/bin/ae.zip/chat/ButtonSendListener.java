package chat;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;

import javax.swing.JTextField;

import cipherModes.CBC;
import cipherModes.CTR;
import cipherModes.CipherMode;
import cipherModes.ECB;
import cipherModes.RC4;

public class ButtonSendListener implements ActionListener
{

    Socket _client;
    JTextField _textMessage;
    String _clientName;
    CipherMode _cipherMode;
    
    public ButtonSendListener(Socket pClient, JTextField pTextMessage, JTextField pClientName, String pCipherMode)
    {
        _client = pClient;
        _textMessage = pTextMessage;
        _clientName = pClientName.getText();
        setCipherMode(pCipherMode);
    }
    
    public void setCipherMode(String pCipherMode)
    {
        if(pCipherMode.equals("ECB"))
        {
            _cipherMode = new ECB();
        }
        else if(pCipherMode.equals("CBC"))
        {
            _cipherMode = new CBC();
        }
        else if(pCipherMode.equals("CTR"))
        {
            _cipherMode = new CTR();
        }
        else if(pCipherMode.equals("RC4"))
        {
            _cipherMode = new RC4("padrao".getBytes());
        } 
            
    }
    @Override
    public void actionPerformed(ActionEvent arg0)
    {
        PrintStream saida;
        try
        {
            saida = new PrintStream(_client.getOutputStream());
            String msg = null;
            if(!(_cipherMode instanceof RC4))
            {
                msg = _cipherMode.makeCipher(_clientName + ":" +_textMessage.getText());
                saida.println(msg);
            }
            else
            {
                String msgRC4 = _clientName + " "  + ":" + " " +_textMessage.getText();
                byte[] msgfinal = _cipherMode.makeCipher(msgRC4.getBytes());
                String str = new String(msgfinal); 
                saida.println(str);
            }
           
            _textMessage.setText("");
        } catch (IOException e)
        {
            e.printStackTrace();
        }
               
        
    }

}
