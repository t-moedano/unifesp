#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>

#define	N 10000000
#define MAX_THREADS 32

typedef struct thread_inf
{
	int start;
	int end;
} ThreadInf;

int cont = 0;
double *array, *arrayAux;
ThreadInf threadInf[MAX_THREADS];
pthread_t t[MAX_THREADS];


void *callMerge(void *thread)
{
	ThreadInf *aux;
	aux = (ThreadInf*) thread;
	mergeSort(aux->start, aux->end);
}

void mergeSortThreads(int inicio, int meio, int fim)
{	
	int threadA, threadB;
	threadA = cont++;
	threadInf[threadA].start = inicio;
	threadInf[threadA].end = meio;

	pthread_create(&t[threadA],NULL,&callMerge,(void*)&threadInf[threadA]);
	pthread_join(t[threadA], NULL);

	if(cont < MAX_THREADS-1)
	{	
		threadB = cont++;
		threadInf[threadB].start = meio+1;
		threadInf[threadB].end = fim;
		pthread_create(&t[threadB],NULL,&callMerge,(void*)&threadInf[threadB]);
		pthread_join(t[threadB], NULL);
	}
	else
		mergeSort(meio+1,fim);

}

void intercala(int inicio, int meio, int fim)
{
   int i, j, k;
   for(k=inicio; k<=meio; ++k)
        arrayAux[k] = array[k];
   j = meio+1;
   for(k=0; k<(fim-meio); ++k)
        arrayAux[k+j] = array[fim-k];
   i = inicio, j = fim;
   for(k=inicio; k<=fim; ++k){
        if(arrayAux[i]<=arrayAux[j])
            array[k] = arrayAux[i++];
        else
            array[k] = arrayAux[j--];
   }
}

void mergeSort(int inicio, int fim)
{
    int meio;
    if(inicio<fim){
        meio = (inicio+fim)/2;
        if(cont < MAX_THREADS)
            mergeSortThreads(inicio, meio, fim);
        else{
            mergeSort(inicio, meio);
            mergeSort(meio+1, fim);
        }
        intercala(inicio, meio, fim);
    }
}


int main()
{
    int i;
    double tmiliThreads;
    struct timeval inicioThreads, fimThreads;

    array = (double*) malloc(N*sizeof(double));
    arrayAux = (double*) malloc(N*sizeof(double));
    srand((unsigned int)time(NULL));
    for(i=0; i<N; ++i)
        array[i] = (rand()%(N/10)+(rand()/(double)(N/10)));

    gettimeofday(&inicioThreads,NULL);
    mergeSort(0,N-1);
    gettimeofday(&fimThreads,NULL);
    tmiliThreads = (double)(1000.0*(fimThreads.tv_sec-inicioThreads.tv_sec)+(fimThreads.tv_usec-inicioThreads.tv_usec)/1000.0);

    printf("Tempo decorrido com %d Threads: %.3lf milissegundos\n", MAX_THREADS, tmiliThreads);

    free(array);
    free(arrayAux);

    return 0;
}




