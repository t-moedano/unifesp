public class CalcThE {
	final static int N = 5;
	static double[][] m1 = new double[N][N];
	static double[][] m2 = new double[N][N];
	static double[][] retorno = new double[N][N];
	
    public static void
    main(String args[]) {
        
        int MaxThreads = 2, i, j;
        int ratio = (N/MaxThreads);
        Thread[] th;
        RunThE[] rh;
    //    double resfinal = 0;
        rh = new RunThE[MaxThreads];
        th = new Thread[MaxThreads];
        
        for(i = 0; i < CalcThE.N; i++) {
        	for(j = 0; j < CalcThE.N; j++) {
        		m1[i][j] = (Math.random()*10);
        		m2[i][j] = (Math.random()*10);
        	}
        	
        }
        
        long startTime = System.currentTimeMillis();
        for(i=0; i<MaxThreads; i++) {
            int end =  ((i!=(MaxThreads-1)) ? ((ratio*(i+1))-1) : CalcThE.N-1);
            rh[i] = new RunThE(ratio*i, end);
            th[i] = new Thread(rh[i]);
            th[i].start();
        }

        try {
            for(i=0; i<MaxThreads; i++) {
                th[i].join();
               // resfinal += rh[i].valor;
            }
        } catch (InterruptedException e)
        { System.out.println("Excecao"); }
        long calcTime = System.currentTimeMillis() - startTime;
        for(i = 0; i < CalcThE.N; i++) {
        	for(j = 0; j < CalcThE.N; j++) {
        		System.out.print(CalcThE.retorno[i][j] + " ");
        	}
    		System.out.println("");
        }
        System.out.println("Em " + calcTime + "ms.\n");
        
    }
}