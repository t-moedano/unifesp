package chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.JTextArea;

import cipherModes.CipherMode;

public class Recebedor implements Runnable {

    private InputStream servidor;
    private JTextArea _textArea;
    private CipherMode cipherMode;
    public Recebedor(InputStream servidor, JTextArea pJTextArea, CipherMode pCipherMode) 
    {
        this.servidor = servidor;
        _textArea = pJTextArea;
        cipherMode = pCipherMode;
    }

    public void run() {
        // recebe msgs do servidor e imprime na tela
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.servidor));
        String line;
        try
        {
            while (( line = bufferedReader.readLine()) != null) 
            {
                line = cipherMode.makePlainText(line);
                System.out.println(line + "desecrmtgjdof");
                _textArea.append(line);
                _textArea.append("\n");
            }
        } catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
    }
}
