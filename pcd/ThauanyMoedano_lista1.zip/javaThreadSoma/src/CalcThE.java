public class CalcThE {
    public static void
    main(String args[]) {
        int MaxThreads = 2, i;
        int ratio = (RunThE.N/MaxThreads);
        Thread[] th;
        RunThE[] rh;
        double resfinal=0;
        rh = new RunThE[MaxThreads];
        th = new Thread[MaxThreads];
        long startTime = System.currentTimeMillis();
        for(i=0; i<MaxThreads; i++) {
            int end =  ((i!=(MaxThreads-1)) ? ((ratio*(i+1))-1) : RunThE.N-1);
            rh[i] = new RunThE(ratio*i, end);
            th[i] = new Thread(rh[i]);
            th[i].start();
        }

        try {
            for(i=0; i<MaxThreads; i++) {
                th[i].join();
                resfinal += rh[i].valor;
            }
        } catch (InterruptedException e)
        { System.out.println("Excecao"); }
        long calcTime = System.currentTimeMillis() - startTime;
        System.out.println("Resultado=" +
                (double)resfinal/RunThE.N);
        System.out.println("Em " + calcTime + "ms.\n");
        
    }
}