package chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.JTextArea;

import cipherModes.CipherMode;
import cipherModes.RC4;

public class Recebedor implements Runnable {

    private InputStream servidor;
    private JTextArea _textArea;
    private CipherMode cipherMode;
    public Recebedor(InputStream servidor, JTextArea pJTextArea, CipherMode pCipherMode) 
    {
        this.servidor = servidor;
        _textArea = pJTextArea;
        cipherMode = pCipherMode;
    }

    public void run() {
        // recebe msgs do servidor e imprime na tela
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.servidor));
        String line;
        try
        {
            if(!(cipherMode instanceof RC4)) {
                while ((line = bufferedReader.readLine()) != null) {
                    line = cipherMode.makePlainText(line);
                    System.out.println(line);
                    _textArea.append(line);
                    _textArea.append("\n");
                }
            }
            else
            {
                while ((line = bufferedReader.readLine()) != null) {
                    line = new String(cipherMode.makePlainText(line.getBytes()));
                    System.out.println(line);
                    _textArea.append(line);
                    _textArea.append("\n");
                }
            }
        } catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
    }
}
