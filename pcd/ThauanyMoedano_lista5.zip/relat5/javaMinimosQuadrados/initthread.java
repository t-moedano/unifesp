import java.util.Random;

// classe que implementa as threads

class initthread implements Runnable {
    public static double arrayX[] = new double[monitorJava.N];
    public static double arrayY[] = new double[monitorJava.N];
   //Variaveis globais que armazenam as somas parciais
    static double SUMxglobal = 0.0, SUMyglobal = 0.0, SUMxxglobal = 0.0, SUMxyglobal = 0.0;
    private int inic, fim;
    int t;
    Random numero = new Random();
    //inicializa a thread
    public initthread(int inic, int fim) {
        super();      
        this.inic = inic;
        this.fim = fim;
    }
   //método-monitor
    public synchronized void Mostra(double SUMx, double SUMy, double SUMxx, double SUMxy){
        initthread.SUMxglobal += SUMx;
        initthread.SUMyglobal += SUMy;
        initthread.SUMxxglobal += SUMxx;
        initthread.SUMxyglobal += SUMxy;
    }
   
   //método que executa a soma com deslocamento fixo em x e um número random em y
    public void run () {
        double SUMxlocal = 0.0, SUMylocal = 0.0, SUMxxlocal = 0.0, SUMxylocal = 0.0;
        for(int k = inic; k < fim; k++) {
            
            
            arrayX[k] = (float)k*10/monitorJava.N;
            arrayY[k] = numero.nextDouble();
        
            SUMxlocal += arrayX[k];
            SUMylocal += arrayY[k];
            SUMxylocal += arrayX[k]*arrayY[k];
            SUMxxlocal += arrayX[k]*arrayX[k];
           
        }
        
        Mostra(SUMxlocal, SUMylocal, SUMxxlocal, SUMxylocal);
    }
   
}
