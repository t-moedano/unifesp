#include <stdio.h> 
#include <pthread.h> 
#include <stdlib.h>
#include <time.h>
#include <omp.h>
 
#define N 10000000

 
typedef struct thread_information{ 
    int thread_id; 
    int start; 
    int end; 
} TInformation; 
 
 
 
double *arrayX;
double *arrayY;
 
 
int main(void) {
    
    int i;
    double seed, value, m, b;
    double start, end, run;
    double globalSUMx = 0.0, globalSUMy = 0.0, globalSUMxx = 0.0,
    globalSUMxy = 0.0;     
    
    arrayX = (double*) malloc(N*sizeof(double));
    arrayY = (double*) malloc(N*sizeof(double));
    arrayX[0] = 0;
    for(i = 0; i < N; i++) {
         
    }
    start = omp_get_wtime();   
    //omp_set_dynamic(0);     
    omp_set_num_threads(1); 
    #pragma omp parallel private(i) reduction(+:globalSUMx) reduction(+:globalSUMy) reduction(+:globalSUMxx) reduction(+:globalSUMxy) 
    {
    #pragma omp for
    for(i = 0; i < N; i++) {
    	seed = time(NULL);
        arrayX[i] = (i*10)/N;
    	value = rand_r(&seed)%100;
        arrayY[i] = value;
        globalSUMx += arrayX[i];
    	globalSUMxx += arrayX[i]*arrayX[i];
    	globalSUMy += arrayY[i];
    	globalSUMxy += arrayX[i]*arrayY[i];
     }
    }
    
 m = (globalSUMx*globalSUMy - N*globalSUMxy)
                / (globalSUMx*globalSUMx - N*globalSUMxx);
b =  (globalSUMy - m*globalSUMx) / N;
printf("Função: y = %lf x + %lf\n\n", m, b);	
 
     end = omp_get_wtime();
    printf("%f ms\n", (end-start)*1000);
    return(0);
}
