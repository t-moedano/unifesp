package chat;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;

import javax.swing.JTextField;

import cipherModes.ECB;

public class ButtonSendListener implements ActionListener
{

    Socket _client;
    JTextField _textMessage;
    String _clientName;
    
    public ButtonSendListener(Socket pClient, JTextField pTextMessage, JTextField pClientName)
    {
        _client = pClient;
        _textMessage = pTextMessage;
        _clientName = pClientName.getText();
    }
    @Override
    public void actionPerformed(ActionEvent arg0)
    {
        PrintStream saida;
        try
        {
            ECB ecb = new ECB();
            saida = new PrintStream(_client.getOutputStream());
            String msg = ecb.makeCipher(_clientName + ":" + _textMessage.getText());
            saida.println(msg);
            _textMessage.setText("");
        } catch (IOException e)
        {
            e.printStackTrace();
        }
               
        
    }

}
