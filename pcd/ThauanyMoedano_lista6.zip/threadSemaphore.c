#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define K 5
#define MAX_THREADS 8
#define CARGA 100

pthread_mutex_t semaphore, gate;
int counter = K;
int block[MAX_THREADS];

void *threadSemaphore(void *thread)
{
	long tID = (long) thread;
	int i;
	/*Wait*/
	pthread_mutex_lock(&gate);

	if(counter > 0)
		counter--;

	else{
		pthread_mutex_lock(&gate);
		block[tID] = 1;
	}


	printf("Entra %ld\n", tID);
    for(i=0; i < CARGA*(tID); i++);
         /*Processa SC*/
   		 printf("Processa %ld\n", tID);

   	 for(i=0; i < CARGA*(tID); i++);
    		printf("Sai %ld\n", tID);

	int flag = 0;
	for(i = 0; i < MAX_THREADS; i++)
	{
		if(block[i] == 1)
			flag = 1;
	}
	if(flag == 0)
	{
		counter++;
	}
	else
    {
        for(i = 0; i < MAX_THREADS; i++)
        {
            if(block[i] == 1)
            {
                 block[i] = 0;
                 break;
            }

        }
        pthread_mutex_unlock(&gate);
    }


	flag = 0;
	pthread_exit(NULL);

}

int main()
{
    long i;
    pthread_t t[MAX_THREADS];
    for(i = 0; i < MAX_THREADS; i++)
    {
//	counter[i] = K;
	block[i] = 0;
    }
    for(i = 0; i < MAX_THREADS; i++)
        pthread_create(&t[i],NULL,&threadSemaphore,(void *)i);
    for(i = 0; i < MAX_THREADS; i++)
        pthread_join(t[i],NULL);
    return 0;
}


